import { Emotion } from '../types/voice';

const POSITIVE_KEYWORDS = [
  'happy', 'good', 'great', 'better', 'improving',
  'thank', 'thanks', 'grateful', 'appreciate',
  'hopeful', 'confident', 'optimistic'
];

const NEGATIVE_KEYWORDS = [
  'pain', 'hurt', 'worse', 'bad', 'sick',
  'worried', 'anxious', 'scared', 'afraid',
  'terrible', 'awful', 'uncomfortable'
];

export function analyzeEmotion(text: string): Emotion {
  const lowerText = text.toLowerCase();
  
  const positiveCount = POSITIVE_KEYWORDS.filter(word => 
    lowerText.includes(word)
  ).length;
  
  const negativeCount = NEGATIVE_KEYWORDS.filter(word => 
    lowerText.includes(word)
  ).length;

  if (positiveCount > negativeCount) return 'positive';
  if (negativeCount > positiveCount) return 'negative';
  return 'neutral';
}