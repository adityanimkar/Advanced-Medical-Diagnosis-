import { findRelevantResponse } from './medicalDataset';
import { Emotion } from '../../types/voice';

export function generateResponse(input: string, emotion: Emotion): string {
  // Get medical response based on symptoms
  const medicalResponse = findRelevantResponse(input);
  
  // If high confidence in medical response, use it
  if (medicalResponse.confidence > 0.7) {
    return medicalResponse.text;
  }

  // Otherwise, handle based on emotion
  if (emotion === 'negative') {
    return "I understand you're not feeling well. Could you tell me more about your symptoms?";
  } else if (emotion === 'positive') {
    return "I'm glad you're feeling better! Is there anything specific you'd like to discuss about your health?";
  }

  return "How can I assist you with your health concerns today?";
}