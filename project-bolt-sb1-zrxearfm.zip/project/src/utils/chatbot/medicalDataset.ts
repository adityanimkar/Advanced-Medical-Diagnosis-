import { ChatResponse } from '../../types/chat';

// Medical conversation dataset
const medicalConversations = [
  {
    type: 'general',
    symptoms: ['fatigue', 'headache', 'loss of appetite'],
    conversation: [
      { role: 'patient', text: "I've been feeling tired all the time and having headaches." },
      { role: 'doctor', text: "Have you experienced any other symptoms, such as fever or changes in appetite?" }
    ]
  },
  {
    type: 'diabetes',
    symptoms: ['high blood sugar', 'thirst', 'frequent urination'],
    conversation: [
      { role: 'doctor', text: "How have you been managing your blood sugar levels?" },
      { role: 'patient', text: "I've been monitoring it daily, but it spikes after meals." }
    ]
  },
  // Add more conversations from the dataset...
];

export function findRelevantResponse(input: string): ChatResponse {
  const normalizedInput = input.toLowerCase();
  
  // Check for symptoms in the input
  const matchedConversation = medicalConversations.find(conv => 
    conv.symptoms.some(symptom => normalizedInput.includes(symptom))
  );

  if (matchedConversation) {
    const doctorResponses = matchedConversation.conversation
      .filter(msg => msg.role === 'doctor')
      .map(msg => msg.text);
    
    return {
      text: doctorResponses[Math.floor(Math.random() * doctorResponses.length)],
      type: matchedConversation.type,
      confidence: 0.8
    };
  }

  // Default response if no match found
  return {
    text: "I understand you may have health concerns. Could you please describe your symptoms in more detail?",
    type: 'general',
    confidence: 0.5
  };
}