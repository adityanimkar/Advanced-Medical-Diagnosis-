import medicalData from './medical-data.json';

export interface ChatbotDataset {
  intents: {
    tag: string;
    patterns: string[];
    responses: string[];
  }[];
}

export const dataset: ChatbotDataset = medicalData;

export function findBestMatch(input: string, patterns: string[]): number {
  let maxScore = 0;
  let bestIndex = 0;

  patterns.forEach((pattern, index) => {
    const score = calculateSimilarity(input.toLowerCase(), pattern.toLowerCase());
    if (score > maxScore) {
      maxScore = score;
      bestIndex = index;
    }
  });

  return maxScore > 0.6 ? bestIndex : -1;
}

function calculateSimilarity(str1: string, str2: string): number {
  const words1 = str1.split(' ');
  const words2 = str2.split(' ');
  const commonWords = words1.filter(word => words2.includes(word));
  return commonWords.length / Math.max(words1.length, words2.length);
}