export interface HealthMetric {
  score: number;
  level: 'Low' | 'Medium' | 'High';
  color: 'green' | 'yellow' | 'red';
}

const SEVERITY_LEVELS = {
  CRITICAL: {
    symptoms: ['Chest Pain', 'Shortness of Breath', 'High Blood Pressure', 'Seizures', 'Coughing Blood'],
    weight: 5
  },
  SEVERE: {
    symptoms: ['Fever', 'Irregular Heartbeat', 'Severe Pain', 'Confusion', 'Blood in Stool'],
    weight: 4
  },
  MODERATE: {
    symptoms: ['Headache', 'Dizziness', 'Nausea', 'Vomiting', 'Joint Pain'],
    weight: 3
  },
  MILD: {
    symptoms: ['Fatigue', 'Cough', 'Sore Throat', 'Runny Nose', 'Mild Pain'],
    weight: 2
  },
  LOW: {
    symptoms: ['Sneezing', 'Itching', 'Mild Discomfort'],
    weight: 1
  }
};

export const calculateHealthMetrics = (symptoms: string[]): HealthMetric => {
  const getSymptomWeight = (symptom: string): number => {
    for (const [severity, data] of Object.entries(SEVERITY_LEVELS)) {
      if (data.symptoms.includes(symptom)) {
        return data.weight;
      }
    }
    return SEVERITY_LEVELS.MODERATE.weight; // Default to moderate if not found
  };

  const totalSeverity = symptoms.reduce((acc, symptom) => 
    acc + getSymptomWeight(symptom), 0);
  
  const maxPossibleSeverity = 5 * symptoms.length;
  const score = 100 - ((totalSeverity / maxPossibleSeverity) * 100);

  return {
    score,
    level: score >= 70 ? 'Low' : score >= 40 ? 'Medium' : 'High',
    color: score >= 70 ? 'green' : score >= 40 ? 'yellow' : 'red'
  };
};