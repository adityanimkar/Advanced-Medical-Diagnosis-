import * as faceapi from 'face-api.js';

export async function loadFaceDetectionModels() {
  try {
    // Load models from CDN instead of local files
    const MODEL_URL = 'https://justadudewhohacks.github.io/face-api.js/models';
    
    await Promise.all([
      faceapi.nets.tinyFaceDetector.loadFromUri(MODEL_URL),
      faceapi.nets.faceExpressionNet.loadFromUri(MODEL_URL),
      faceapi.nets.faceLandmark68Net.loadFromUri(MODEL_URL),
    ]);
    
    return true;
  } catch (error) {
    console.error('Error loading face detection models:', error);
    return false;
  }
}