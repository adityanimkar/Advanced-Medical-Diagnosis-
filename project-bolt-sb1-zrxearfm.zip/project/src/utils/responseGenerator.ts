const RESPONSES = {
  greeting: [
    "Hello! How are you feeling today?",
    "Hi there! What brings you here today?",
    "Welcome! How can I assist you with your health concerns?"
  ],
  
  positive: [
    "I'm glad you're feeling better!",
    "That's great to hear! Keep up the good work.",
    "Wonderful progress! Is there anything specific you'd like to discuss?"
  ],
  
  negative: [
    "I'm sorry you're not feeling well. Can you tell me more about your symptoms?",
    "I understand this must be difficult. Let's work together to help you feel better.",
    "I hear your concerns. Would you like to discuss your symptoms in detail?"
  ],
  
  neutral: [
    "How can I help you today?",
    "What would you like to discuss about your health?",
    "Is there anything specific you'd like to know?"
  ]
};

export function generateResponse(userMessage: string, emotion: string): string {
  const lowerMessage = userMessage.toLowerCase();
  
  // Check for greetings
  if (lowerMessage.includes('hello') || lowerMessage.includes('hi')) {
    return getRandomResponse('greeting');
  }
  
  // Return emotion-based response
  return getRandomResponse(emotion as keyof typeof RESPONSES);
}

function getRandomResponse(type: keyof typeof RESPONSES): string {
  const responses = RESPONSES[type];
  return responses[Math.floor(Math.random() * responses.length)];
}