import { Disease, Symptom, Hospital } from '../types/medical';

export const symptoms: Symptom[] = [
  // General Symptoms
  { id: '1', name: 'Fever', category: 'General' },
  { id: '2', name: 'Fatigue', category: 'General' },
  { id: '3', name: 'Weakness', category: 'General' },
  { id: '4', name: 'Night Sweats', category: 'General' },
  { id: '5', name: 'Weight Loss', category: 'General' },
  { id: '6', name: 'Weight Gain', category: 'General' },
  { id: '7', name: 'Loss of Appetite', category: 'General' },
  { id: '8', name: 'Excessive Thirst', category: 'General' },

  // Neurological Symptoms
  { id: '9', name: 'Headache', category: 'Neurological' },
  { id: '10', name: 'Dizziness', category: 'Neurological' },
  { id: '11', name: 'Memory Problems', category: 'Neurological' },
  { id: '12', name: 'Confusion', category: 'Neurological' },
  { id: '13', name: 'Seizures', category: 'Neurological' },
  { id: '14', name: 'Tremors', category: 'Neurological' },
  { id: '15', name: 'Balance Problems', category: 'Neurological' },
  { id: '16', name: 'Numbness', category: 'Neurological' },
  { id: '17', name: 'Tingling', category: 'Neurological' },

  // Respiratory Symptoms
  { id: '18', name: 'Cough', category: 'Respiratory' },
  { id: '19', name: 'Shortness of Breath', category: 'Respiratory' },
  { id: '20', name: 'Wheezing', category: 'Respiratory' },
  { id: '21', name: 'Chest Congestion', category: 'Respiratory' },
  { id: '22', name: 'Rapid Breathing', category: 'Respiratory' },
  { id: '23', name: 'Coughing Blood', category: 'Respiratory' },

  // Cardiovascular Symptoms
  { id: '24', name: 'Chest Pain', category: 'Cardiovascular' },
  { id: '25', name: 'Palpitations', category: 'Cardiovascular' },
  { id: '26', name: 'High Blood Pressure', category: 'Cardiovascular' },
  { id: '27', name: 'Low Blood Pressure', category: 'Cardiovascular' },
  { id: '28', name: 'Irregular Heartbeat', category: 'Cardiovascular' },
  { id: '29', name: 'Swelling in Legs', category: 'Cardiovascular' },

  // Digestive Symptoms
  { id: '30', name: 'Nausea', category: 'Digestive' },
  { id: '31', name: 'Vomiting', category: 'Digestive' },
  { id: '32', name: 'Diarrhea', category: 'Digestive' },
  { id: '33', name: 'Constipation', category: 'Digestive' },
  { id: '34', name: 'Abdominal Pain', category: 'Digestive' },
  { id: '35', name: 'Bloating', category: 'Digestive' },
  { id: '36', name: 'Heartburn', category: 'Digestive' },
  { id: '37', name: 'Blood in Stool', category: 'Digestive' },

  // Musculoskeletal Symptoms
  { id: '38', name: 'Joint Pain', category: 'Musculoskeletal' },
  { id: '39', name: 'Muscle Pain', category: 'Musculoskeletal' },
  { id: '40', name: 'Back Pain', category: 'Musculoskeletal' },
  { id: '41', name: 'Neck Pain', category: 'Musculoskeletal' },
  { id: '42', name: 'Stiffness', category: 'Musculoskeletal' },
  { id: '43', name: 'Swollen Joints', category: 'Musculoskeletal' },

  // Skin Symptoms
  { id: '44', name: 'Rash', category: 'Skin' },
  { id: '45', name: 'Itching', category: 'Skin' },
  { id: '46', name: 'Hives', category: 'Skin' },
  { id: '47', name: 'Bruising', category: 'Skin' },
  { id: '48', name: 'Skin Changes', category: 'Skin' },
  { id: '49', name: 'Dry Skin', category: 'Skin' },

  // Mental Health Symptoms
  { id: '50', name: 'Anxiety', category: 'Mental Health' },
  { id: '51', name: 'Depression', category: 'Mental Health' },
  { id: '52', name: 'Mood Changes', category: 'Mental Health' },
  { id: '53', name: 'Sleep Problems', category: 'Mental Health' },
  { id: '54', name: 'Irritability', category: 'Mental Health' },
  { id: '55', name: 'Stress', category: 'Mental Health' },

  // And many more categories...
];

export const diseases: Disease[] = [
  {
    id: '1',
    name: 'Common Cold',
    description: 'A viral infection of the upper respiratory tract that typically resolves within 7-10 days.',
    symptoms: ['Fever', 'Cough', 'Fatigue'],
    medications: [
      {
        name: 'Acetaminophen',
        dosage: '500mg',
        frequency: 'Every 6 hours',
        duration: '5 days'
      },
      {
        name: 'Dextromethorphan',
        dosage: '30mg',
        frequency: 'Every 6-8 hours',
        duration: '5 days'
      }
    ]
  },
  {
    id: '2',
    name: 'Migraine',
    description: 'A neurological condition characterized by severe headaches, often accompanied by other symptoms.',
    symptoms: ['Headache', 'Nausea', 'Dizziness'],
    medications: [
      {
        name: 'Sumatriptan',
        dosage: '50mg',
        frequency: 'As needed',
        duration: 'Single dose'
      },
      {
        name: 'Rizatriptan',
        dosage: '10mg',
        frequency: 'As needed',
        duration: 'Single dose'
      }
    ]
  },
  {
    id: '3',
    name: 'Bronchitis',
    description: 'An inflammation of the bronchial tubes that carry air to and from the lungs.',
    symptoms: ['Cough', 'Shortness of Breath', 'Chest Congestion'],
    medications: [
      {
        name: 'Amoxicillin',
        dosage: '500mg',
        frequency: 'Every 8 hours',
        duration: '7 days'
      },
      {
        name: 'Guaifenesin',
        dosage: '400mg',
        frequency: 'Every 4 hours',
        duration: '7 days'
      }
    ]
  },
  {
    id: '4',
    name: 'Anxiety Disorder',
    description: 'A mental health condition characterized by persistent feelings of worry and fear.',
    symptoms: ['Anxiety', 'Sleep Problems', 'Palpitations'],
    medications: [
      {
        name: 'Sertraline',
        dosage: '50mg',
        frequency: 'Once daily',
        duration: 'As prescribed'
      }
    ]
  },
  {
    id: '5',
    name: 'Gastritis',
    description: 'Inflammation of the stomach lining that can cause various digestive symptoms.',
    symptoms: ['Nausea', 'Abdominal Pain', 'Loss of Appetite'],
    medications: [
      {
        name: 'Omeprazole',
        dosage: '20mg',
        frequency: 'Once daily',
        duration: '14 days'
      }
    ]
  }
];

export const hospitals: Hospital[] = [
  {
    id: '1',
    name: 'Central Medical Center',
    address: '123 Healthcare Ave',
    distance: '2.5 km',
    specialties: ['General Medicine', 'Cardiology', 'Neurology'],
    rating: 4.5
  },
  {
    id: '2',
    name: 'City General Hospital',
    address: '456 Medical Blvd',
    distance: '3.8 km',
    specialties: ['Emergency Care', 'Pediatrics', 'Orthopedics'],
    rating: 4.2
  },
  {
    id: '3',
    name: 'Community Health Center',
    address: '789 Wellness Street',
    distance: '1.5 km',
    specialties: ['Family Medicine', 'Internal Medicine'],
    rating: 4.0
  },
  {
    id: '4',
    name: 'Specialized Care Hospital',
    address: '321 Specialist Road',
    distance: '4.2 km',
    specialties: ['Oncology', 'Neurosurgery', 'Cardiology'],
    rating: 4.7
  },
  {
    id: '5',
    name: 'Emergency Medical Center',
    address: '567 Urgent Care Lane',
    distance: '2.1 km',
    specialties: ['Emergency Medicine', 'Trauma Care', 'Critical Care'],
    rating: 4.4
  }
];