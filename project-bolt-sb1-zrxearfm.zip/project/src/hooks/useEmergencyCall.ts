export function useEmergencyCall() {
  const makeCall = (phoneNumber: string) => {
    window.location.href = `tel:${phoneNumber}`;
  };

  return { makeCall };
}