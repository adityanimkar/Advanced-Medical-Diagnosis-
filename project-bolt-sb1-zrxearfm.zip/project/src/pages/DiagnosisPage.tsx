import React, { useState } from 'react';
import SymptomSelector from '../components/SymptomSelector';
import DiagnosisResultsPage from './DiagnosisResultsPage';
import { Activity } from 'lucide-react';
import { Disease } from '../types/medical';
import { symptoms, diseases } from '../data/medicalData';

export default function DiagnosisPage() {
  const [selectedSymptoms, setSelectedSymptoms] = useState<string[]>([]);
  const [diagnosis, setDiagnosis] = useState<Disease | null>(null);
  const [showResults, setShowResults] = useState(false);

  const handleSymptomSelect = (symptom: string) => {
    setSelectedSymptoms(prev => {
      if (prev.includes(symptom)) {
        return prev.filter(s => s !== symptom);
      }
      if (prev.length >= 5) {
        return prev;
      }
      return [...prev, symptom];
    });
    setShowResults(false);
  };

  const handleDiagnosis = () => {
    if (selectedSymptoms.length < 3) return;

    const matchedDisease = diseases.reduce((best, current) => {
      const matchCount = selectedSymptoms.filter(s => 
        current.symptoms.includes(s)
      ).length;

      return matchCount > (best ? selectedSymptoms.filter(s => 
        best.symptoms.includes(s)
      ).length : -1) ? current : best;
    }, null as Disease | null);

    setDiagnosis(matchedDisease);
    setShowResults(true);
  };

  if (showResults && diagnosis) {
    return (
      <DiagnosisResultsPage
        disease={diagnosis}
        selectedSymptoms={selectedSymptoms}
        onBack={() => setShowResults(false)}
      />
    );
  }

  return (
    <div className="min-h-screen bg-gray-100">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-2">
            <Activity className="text-blue-500" size={24} />
            <h1 className="text-2xl font-bold text-gray-900">Medical Diagnosis System</h1>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        <div className="max-w-2xl mx-auto">
          <SymptomSelector
            symptoms={symptoms}
            selectedSymptoms={selectedSymptoms}
            onSymptomSelect={handleSymptomSelect}
            maxSymptoms={5}
          />

          <div className="flex justify-center mt-6">
            <button
              onClick={handleDiagnosis}
              disabled={selectedSymptoms.length < 3}
              className={`px-6 py-3 rounded-lg font-semibold text-white transition-colors ${
                selectedSymptoms.length >= 3
                  ? 'bg-blue-500 hover:bg-blue-600'
                  : 'bg-gray-400 cursor-not-allowed'
              }`}
            >
              Generate Diagnosis
            </button>
          </div>
        </div>
      </main>
    </div>
  );
}