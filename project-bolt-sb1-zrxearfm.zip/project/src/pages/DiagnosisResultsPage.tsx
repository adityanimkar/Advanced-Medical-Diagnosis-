import React from 'react';
import { Activity, ArrowLeft } from 'lucide-react';
import DiagnosisResult from '../components/DiagnosisResult';
import NearbyHospitals from '../components/NearbyHospitals';
import HealthGraph from '../components/HealthGraph';
import FoodSuggestions from '../components/FoodSuggestions';
import VoiceChat from '../components/VoiceChat/VoiceChat';
import EmergencyButton from '../components/Emergency/EmergencyButton';
import DoctorConsultation from '../components/DoctorConsultation';
import MedicationApproval from '../components/MedicationApproval';
import HospitalMap from '../components/HospitalMap';
import { Disease } from '../types/medical';
import { hospitals } from '../data/medicalData';

interface DiagnosisResultsPageProps {
  disease: Disease;
  selectedSymptoms: string[];
  onBack: () => void;
}

export default function DiagnosisResultsPage({ 
  disease, 
  selectedSymptoms, 
  onBack 
}: DiagnosisResultsPageProps) {
  return (
    <div className="min-h-screen bg-gray-100">
      <EmergencyButton />
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Activity className="text-indigo-500" size={24} />
              <h1 className="text-2xl font-bold text-gray-900">Diagnosis Results</h1>
            </div>
            <button
              onClick={onBack}
              className="flex items-center gap-2 text-gray-600 hover:text-gray-900"
            >
              <ArrowLeft size={20} />
              Back to Symptoms
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="space-y-8">
            <DiagnosisResult
              disease={disease}
              selectedSymptoms={selectedSymptoms}
              hospitals={hospitals}
            />
            <MedicationApproval medications={disease.medications} />
            <FoodSuggestions condition={disease.name} />
          </div>
          <div className="space-y-8">
            <HealthGraph
              disease={disease}
              selectedSymptoms={selectedSymptoms}
            />
            <DoctorConsultation symptoms={selectedSymptoms} />
            <HospitalMap hospitals={hospitals} />
          </div>
        </div>
      </main>

      <VoiceChat />
    </div>
  );
}