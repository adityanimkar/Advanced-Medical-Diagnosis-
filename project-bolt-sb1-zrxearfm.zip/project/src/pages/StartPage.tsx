import React from 'react';
import { Stethoscope } from 'lucide-react';

export default function StartPage({ onStart }: { onStart: () => void }) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-indigo-100 flex flex-col">
      <div className="flex-grow flex items-center justify-center p-4">
        <div className="max-w-2xl w-full text-center space-y-8 bg-white rounded-2xl p-8 shadow-xl">
          <div className="flex justify-center">
            <Stethoscope className="w-20 h-20 text-indigo-500" />
          </div>
          
          <h1 className="text-4xl font-bold text-gray-800">
            Advanced Medical Diagnosis System
          </h1>
          
          <p className="text-lg text-gray-600 max-w-xl mx-auto">
            Get instant medical insights by selecting your symptoms. Our advanced system 
            will analyze your condition and provide detailed medical recommendations.
          </p>

          <div className="space-y-4">
            <button
              onClick={onStart}
              className="px-8 py-4 bg-indigo-500 hover:bg-indigo-600 text-white rounded-lg 
                       font-semibold text-lg transition-colors shadow-lg hover:shadow-xl"
            >
              Start Diagnosis
            </button>
            
            <p className="text-sm text-gray-500">
              Note: This is an AI-powered diagnostic tool and should not replace 
              professional medical advice.
            </p>
          </div>
        </div>
      </div>

      {/* Team Information */}
      <div className="bg-white/80 backdrop-blur-sm py-6 px-4">
        <div className="max-w-4xl mx-auto">
          <div>
            <h3 className="text-lg font-semibold text-gray-800 mb-3">Team Members</h3>
            <ul className="space-y-2 text-gray-600">
              <li>• Shubham Bhor</li>
              <li>• Aditya Nimkar</li>
              <li>• Suraj Pawase</li>
              <li>• Jay Patil</li>
            </ul>
            <p className="mt-2 text-gray-600">
              <strong>Project Guide:</strong> Prof. Sanjeev Shukla
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}