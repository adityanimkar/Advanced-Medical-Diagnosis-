export interface Symptom {
  id: string;
  name: string;
  category: string;
}

export interface Disease {
  id: string;
  name: string;
  description: string;
  symptoms: string[];
  medications: Medication[];
}

export interface Medication {
  name: string;
  dosage: string;
  frequency: string;
  duration: string;
}

export interface ApprovedMedication extends Medication {
  isApproved: boolean;
  approvedBy?: string;
  approvalDate?: Date;
}

export interface Hospital {
  id: string;
  name: string;
  address: string;
  distance: string;
  specialties: string[];
  rating: number;
  coordinates?: {
    latitude: number;
    longitude: number;
  };
}

export type Specialty = 
  | 'Cardiologist'
  | 'Neurologist'
  | 'Pulmonologist'
  | 'Gastroenterologist'
  | 'General Physician'
  | 'Orthopedist'
  | 'Dermatologist'
  | 'ENT Specialist';