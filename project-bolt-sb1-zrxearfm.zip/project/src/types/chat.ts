export interface ChatResponse {
  text: string;
  type: string;
  confidence: number;
}

export interface ConversationMessage {
  role: 'patient' | 'doctor';
  text: string;
}