export type Emotion = 'positive' | 'negative' | 'neutral';

export interface Message {
  text: string;
  isBot: boolean;
  emotion: Emotion;
  timestamp: Date;
}