import React from 'react';
import { Hospital } from '../types/medical';
import { Building2, MapPin, Star } from 'lucide-react';

interface NearbyHospitalsProps {
  hospitals: Hospital[];
}

export default function NearbyHospitals({ hospitals }: NearbyHospitalsProps) {
  return (
    <div className="bg-white p-6 rounded-lg shadow-lg">
      <div className="flex items-center gap-2 mb-6">
        <Building2 className="text-blue-500" />
        <h2 className="text-xl font-semibold">Nearby Hospitals</h2>
      </div>

      <div className="space-y-4">
        {hospitals.map(hospital => (
          <div key={hospital.id} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
            <div className="flex justify-between items-start mb-2">
              <h3 className="text-lg font-medium text-gray-800">{hospital.name}</h3>
              <div className="flex items-center gap-1">
                <Star className="text-yellow-400 fill-current" size={16} />
                <span className="text-sm text-gray-600">{hospital.rating}</span>
              </div>
            </div>

            <div className="flex items-center gap-2 text-gray-600 mb-2">
              <MapPin size={16} />
              <span className="text-sm">{hospital.address} ({hospital.distance})</span>
            </div>

            <div className="flex flex-wrap gap-2 mt-2">
              {hospital.specialties.map((specialty, index) => (
                <span
                  key={index}
                  className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full"
                >
                  {specialty}
                </span>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}