import React from 'react';
import { Apple, Coffee, Fish, Leaf } from 'lucide-react';

interface FoodSuggestionsProps {
  condition: string;
}

export default function FoodSuggestions({ condition }: FoodSuggestionsProps) {
  const getFoodSuggestions = () => {
    const suggestions = {
      recommended: [
        'Fresh fruits and vegetables',
        'Lean proteins',
        'Whole grains',
        'Anti-inflammatory foods',
      ],
      avoid: [
        'Processed foods',
        'Excessive sugar',
        'Saturated fats',
        'Caffeine',
      ],
    };

    return suggestions;
  };

  const suggestions = getFoodSuggestions();

  return (
    <div className="bg-white p-6 rounded-lg shadow-lg">
      <h3 className="text-lg font-semibold text-gray-800 mb-4">Dietary Recommendations</h3>
      
      <div className="space-y-6">
        <div>
          <div className="flex items-center gap-2 mb-3">
            <Apple className="text-green-500" size={20} />
            <h4 className="font-medium text-gray-700">Recommended Foods</h4>
          </div>
          <ul className="space-y-2">
            {suggestions.recommended.map((food, index) => (
              <li key={index} className="flex items-center gap-2 text-sm text-gray-600">
                <Leaf className="text-green-400" size={16} />
                {food}
              </li>
            ))}
          </ul>
        </div>

        <div>
          <div className="flex items-center gap-2 mb-3">
            <Coffee className="text-red-500" size={20} />
            <h4 className="font-medium text-gray-700">Foods to Avoid</h4>
          </div>
          <ul className="space-y-2">
            {suggestions.avoid.map((food, index) => (
              <li key={index} className="flex items-center gap-2 text-sm text-gray-600">
                <span className="text-red-400">•</span>
                {food}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}