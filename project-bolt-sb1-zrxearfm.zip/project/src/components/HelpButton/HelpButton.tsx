import React from 'react';
import { Ambulance, Phone } from 'lucide-react';

export default function HelpButton() {
  const callAmbulance = () => {
    window.location.href = 'tel:108';
  };

  return (
    <button
      onClick={callAmbulance}
      className="fixed top-4 right-4 bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg 
                 shadow-lg flex items-center gap-2 transition-colors"
      aria-label="Call Ambulance"
    >
      <Ambulance size={20} />
      <span className="font-medium">Call 108</span>
      <Phone size={16} className="text-white/80" />
    </button>
  );
}