import React from 'react';
import { Activity, TrendingUp, AlertTriangle } from 'lucide-react';

interface RiskAnalysisProps {
  symptom: string;
  riskLevel: 'High' | 'Medium' | 'Low';
  score: number;
}

export default function RiskAnalysis({ symptom, riskLevel, score }: RiskAnalysisProps) {
  const getRiskColor = () => {
    switch (riskLevel) {
      case 'High': return 'red';
      case 'Medium': return 'yellow';
      case 'Low': return 'green';
    }
  };

  return (
    <div className="bg-gray-50 p-4 rounded-lg hover:shadow-md transition-shadow">
      <div className="flex justify-between items-center mb-3">
        <div className="flex items-center gap-2">
          <Activity className={`text-${getRiskColor()}-500`} size={18} />
          <span className="text-sm font-medium text-gray-700">{symptom}</span>
        </div>
        <div className="flex items-center gap-2">
          <span className={`text-xs font-medium px-3 py-1 rounded-full 
            ${riskLevel === 'High' ? 'bg-red-100 text-red-800' :
              riskLevel === 'Medium' ? 'bg-yellow-100 text-yellow-800' :
              'bg-green-100 text-green-800'}`}>
            {riskLevel} Risk
          </span>
        </div>
      </div>

      <div className="space-y-2">
        <div className="flex justify-between items-center text-xs text-gray-500">
          <span>Risk Score</span>
          <span className="font-medium">{score}%</span>
        </div>
        <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
          <div
            className={`h-full rounded-full transition-all duration-500
              ${riskLevel === 'High' ? 'bg-red-500' :
                riskLevel === 'Medium' ? 'bg-yellow-500' :
                'bg-green-500'}`}
            style={{ width: `${score}%` }}
          />
        </div>
      </div>
    </div>
  );
}