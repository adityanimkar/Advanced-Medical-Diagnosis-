import React from 'react';
import { Phone, User, Star, Clock, MapPin } from 'lucide-react';
import { Specialty } from '../types/medical';

interface Doctor {
  id: string;
  name: string;
  specialty: Specialty;
  experience: string;
  rating: number;
  availability: string;
  phone: string;
  location: string;
}

interface DoctorConsultationProps {
  symptoms: string[];
}

export default function DoctorConsultation({ symptoms }: DoctorConsultationProps) {
  // Match doctors based on symptoms
  const getRelevantDoctors = (symptoms: string[]): Doctor[] => {
    return [
      {
        id: '1',
        name: 'Dr. Sarah Johnson',
        specialty: 'Cardiologist',
        experience: '15 years',
        rating: 4.8,
        availability: 'Available Today',
        phone: '+1234567890',
        location: 'Central Medical Center'
      },
      {
        id: '2',
        name: 'Dr. Michael Chen',
        specialty: 'Neurologist',
        experience: '12 years',
        rating: 4.7,
        availability: 'Next Available: Tomorrow',
        phone: '+1234567891',
        location: 'City General Hospital'
      },
      {
        id: '3',
        name: 'Dr. Emily Rodriguez',
        specialty: 'Pulmonologist',
        experience: '10 years',
        rating: 4.9,
        availability: 'Available Today',
        phone: '+1234567892',
        location: 'Respiratory Care Center'
      },
      {
        id: '4',
        name: 'Dr. James Wilson',
        specialty: 'Gastroenterologist',
        experience: '18 years',
        rating: 4.6,
        availability: 'Available Today',
        phone: '+1234567893',
        location: 'Digestive Health Institute'
      },
      {
        id: '5',
        name: 'Dr. Lisa Patel',
        specialty: 'General Physician',
        experience: '8 years',
        rating: 4.5,
        availability: 'Next Available: Today',
        phone: '+1234567894',
        location: 'Community Health Center'
      }
    ];
  };

  const doctors = getRelevantDoctors(symptoms);

  return (
    <div className="bg-white p-6 rounded-lg shadow-lg">
      <h3 className="text-xl font-semibold text-gray-800 mb-6">Specialist Doctors</h3>
      <div className="space-y-4">
        {doctors.map((doctor) => (
          <div key={doctor.id} className="border rounded-lg p-4 hover:shadow-md transition-all">
            <div className="flex justify-between items-start">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <User className="text-blue-500" size={20} />
                  <h4 className="font-semibold text-gray-800">{doctor.name}</h4>
                </div>
                <p className="text-blue-600 font-medium text-sm mb-2">{doctor.specialty}</p>
                <div className="flex items-center gap-4 text-sm text-gray-600">
                  <span className="flex items-center gap-1">
                    <Star className="text-yellow-400" size={16} />
                    {doctor.rating}
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock size={16} />
                    {doctor.experience}
                  </span>
                </div>
                <div className="flex items-center gap-1 text-sm text-gray-600 mt-2">
                  <MapPin size={16} />
                  {doctor.location}
                </div>
              </div>
              <div className="text-right">
                <span className={`inline-block px-3 py-1 rounded-full text-sm ${
                  doctor.availability.includes('Today')
                    ? 'bg-green-100 text-green-800'
                    : 'bg-yellow-100 text-yellow-800'
                }`}>
                  {doctor.availability}
                </span>
                <a
                  href={`tel:${doctor.phone}`}
                  className="flex items-center gap-2 mt-4 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
                >
                  <Phone size={16} />
                  Contact
                </a>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}