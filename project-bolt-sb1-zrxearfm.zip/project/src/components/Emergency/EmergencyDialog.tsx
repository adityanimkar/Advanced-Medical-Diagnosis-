import React from 'react';
import { Phone, X, Ambulance, ShieldAlert, Siren } from 'lucide-react';
import { useEmergencyCall } from '../../hooks/useEmergencyCall';

interface EmergencyDialogProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function EmergencyDialog({ isOpen, onClose }: EmergencyDialogProps) {
  const { makeCall } = useEmergencyCall();

  if (!isOpen) return null;

  const emergencyNumbers = [
    { name: 'Ambulance', number: '108', icon: Ambulance },
    { name: 'Police', number: '100', icon: ShieldAlert },
    { name: 'Fire', number: '101', icon: Siren },
  ];

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-md m-4">
        <div className="flex items-center justify-between p-4 border-b">
          <h2 className="text-xl font-semibold text-gray-800 flex items-center gap-2">
            <Phone className="text-red-500" />
            Emergency Services
          </h2>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700"
          >
            <X size={20} />
          </button>
        </div>

        <div className="p-4 space-y-4">
          <div className="bg-red-50 p-4 rounded-lg">
            <p className="text-red-800 text-sm">
              Only use these numbers in case of genuine emergencies. Misuse of emergency services is punishable by law.
            </p>
          </div>

          <div className="grid gap-3">
            {emergencyNumbers.map(({ name, number, icon: Icon }) => (
              <button
                key={number}
                onClick={() => makeCall(number)}
                className="flex items-center justify-between p-4 bg-white border rounded-lg hover:bg-gray-50 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <Icon className="text-red-500" size={24} />
                  <div className="text-left">
                    <div className="font-medium text-gray-900">{name}</div>
                    <div className="text-sm text-gray-500">{number}</div>
                  </div>
                </div>
                <Phone size={20} className="text-green-500" />
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}