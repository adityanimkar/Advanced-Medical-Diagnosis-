import React, { useState } from 'react';
import { Phone, AlertTriangle } from 'lucide-react';
import EmergencyDialog from './EmergencyDialog';

export default function EmergencyButton() {
  const [showDialog, setShowDialog] = useState(false);

  return (
    <>
      <button
        onClick={() => setShowDialog(true)}
        className="fixed top-4 right-4 bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg shadow-lg flex items-center gap-2 transition-colors"
        aria-label="Emergency Call"
      >
        <AlertTriangle size={20} />
        <span>Emergency</span>
      </button>

      <EmergencyDialog
        isOpen={showDialog}
        onClose={() => setShowDialog(false)}
      />
    </>
  );
}