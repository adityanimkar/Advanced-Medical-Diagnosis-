import React, { useState, useEffect, useCallback } from 'react';
import { Mic, MicOff, Volume2, VolumeX, MessageCircle } from 'lucide-react';
import { useVoiceRecognition } from '../../hooks/useVoiceRecognition';
import { useSpeechSynthesis } from '../../hooks/useSpeechSynthesis';
import { analyzeEmotion } from '../../utils/emotionAnalysis';
import { generateResponse } from '../../utils/responseGenerator';
import VoiceChatMessage from './VoiceChatMessage';
import TextInput from './TextInput';
import { Message } from '../../types/voice';

export default function VoiceChat() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [inputMode, setInputMode] = useState<'voice' | 'text'>('voice');

  const { transcript, startListening, stopListening, resetTranscript, isSupported } = useVoiceRecognition();
  const { speak, cancel, isSupported: isSpeechSupported } = useSpeechSynthesis();

  const handleMessage = useCallback(async (text: string) => {
    const emotion = analyzeEmotion(text);
    const userMessage: Message = {
      text,
      isBot: false,
      emotion,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);

    const response = generateResponse(text, emotion);
    const botMessage: Message = {
      text: response,
      isBot: true,
      emotion: 'neutral',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, botMessage]);
    
    if (inputMode === 'voice') {
      setIsSpeaking(true);
      await speak(response);
      setIsSpeaking(false);
    }
  }, [speak, inputMode]);

  useEffect(() => {
    if (transcript) {
      handleMessage(transcript);
      resetTranscript();
    }
  }, [transcript, handleMessage, resetTranscript]);

  const toggleListening = () => {
    if (isListening) {
      stopListening();
      setIsListening(false);
    } else {
      startListening();
      setIsListening(true);
    }
  };

  const toggleSpeech = () => {
    if (isSpeaking) {
      cancel();
      setIsSpeaking(false);
    }
  };

  if (!isSupported || !isSpeechSupported) {
    return null;
  }

  return (
    <div className="fixed bottom-4 right-4 z-50">
      {isOpen && (
        <div className="bg-white rounded-lg shadow-xl w-80 h-96 flex flex-col">
          <div className="bg-blue-500 text-white p-4 rounded-t-lg flex items-center justify-between">
            <h3 className="font-semibold">Voice Assistant</h3>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setInputMode(mode => mode === 'voice' ? 'text' : 'voice')}
                className="p-1 hover:bg-blue-600 rounded"
              >
                {inputMode === 'voice' ? <MessageCircle size={20} /> : <Mic size={20} />}
              </button>
              {inputMode === 'voice' && (
                <>
                  {isSpeaking && (
                    <button onClick={toggleSpeech} className="p-1 hover:bg-blue-600 rounded">
                      <Volume2 size={20} />
                    </button>
                  )}
                  <button
                    onClick={toggleListening}
                    className={`p-1 hover:bg-blue-600 rounded ${isListening ? 'bg-blue-600' : ''}`}
                  >
                    {isListening ? <Mic size={20} /> : <MicOff size={20} />}
                  </button>
                </>
              )}
            </div>
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {messages.map((message, index) => (
              <VoiceChatMessage key={index} message={message} />
            ))}
          </div>

          <div className="p-4 border-t bg-gray-50">
            {inputMode === 'voice' ? (
              isListening && (
                <div className="text-center text-sm text-gray-600">
                  Listening... {transcript && `"${transcript}"`}
                </div>
              )
            ) : (
              <TextInput onSend={handleMessage} />
            )}
          </div>
        </div>
      )}

      <button
        onClick={() => setIsOpen(!isOpen)}
        className="bg-blue-500 text-white p-4 rounded-full shadow-lg hover:bg-blue-600 transition-colors"
      >
        {isOpen ? <MicOff size={24} /> : <Mic size={24} />}
      </button>
    </div>
  );
}