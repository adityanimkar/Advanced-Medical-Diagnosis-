import React from 'react';
import { Message } from '../../types/voice';
import { format } from 'date-fns';

interface VoiceChatMessageProps {
  message: Message;
}

export default function VoiceChatMessage({ message }: VoiceChatMessageProps) {
  const { text, isBot, emotion, timestamp } = message;

  return (
    <div className={`flex ${isBot ? 'justify-start' : 'justify-end'}`}>
      <div
        className={`max-w-[80%] rounded-lg p-3 ${
          isBot
            ? 'bg-gray-100 text-gray-800'
            : 'bg-blue-500 text-white'
        }`}
      >
        <p className="text-sm">{text}</p>
        <div className="flex items-center justify-between mt-1 text-xs opacity-75">
          <span>{format(timestamp, 'HH:mm')}</span>
          {!isBot && (
            <span className={`ml-2 px-2 py-0.5 rounded-full ${
              emotion === 'positive' ? 'bg-green-200 text-green-800' :
              emotion === 'negative' ? 'bg-red-200 text-red-800' :
              'bg-gray-200 text-gray-800'
            }`}>
              {emotion}
            </span>
          )}
        </div>
      </div>
    </div>
  );
}