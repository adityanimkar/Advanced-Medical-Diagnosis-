import React from 'react';
import { Smile, Frown, Meh } from 'lucide-react';
import { Emotion } from '../../types/voice';

interface EmotionIndicatorProps {
  emotion: Emotion;
}

export default function EmotionIndicator({ emotion }: EmotionIndicatorProps) {
  const getEmotionIcon = () => {
    switch (emotion) {
      case 'positive':
        return <Smile className="text-green-300" />;
      case 'negative':
        return <Frown className="text-red-300" />;
      default:
        return <Meh className="text-gray-300" />;
    }
  };

  return (
    <div className="flex items-center gap-2">
      {getEmotionIcon()}
      <span className="text-sm capitalize">{emotion}</span>
    </div>
  );
}