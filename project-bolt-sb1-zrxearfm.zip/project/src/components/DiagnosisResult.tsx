import React from 'react';
import { Disease } from '../types/medical';
import { Pill } from 'lucide-react';
import { MedicationList } from './MedicationList';
import PDFDownloadButton from './PDFReport';
import { useState } from 'react';

interface DiagnosisResultProps {
  disease: Disease | null;
  selectedSymptoms: string[];
  hospitals: any[];
}

export default function DiagnosisResult({ disease, selectedSymptoms, hospitals }: DiagnosisResultProps) {
  const [approvedMedications, setApprovedMedications] = useState(
    disease?.medications.map(med => ({
      ...med,
      isApproved: false,
      approvedBy: undefined,
      approvalDate: undefined
    })) || []
  );

  if (!disease) return null;

  return (
    <div className="bg-white p-6 rounded-lg shadow-lg">
      <div className="mb-6">
        <div className="flex justify-between items-start">
          <h2 className="text-2xl font-bold text-gray-800 mb-2">{disease.name}</h2>
          <PDFDownloadButton 
            disease={disease}
            selectedSymptoms={selectedSymptoms}
            hospitals={hospitals}
            approvedMedications={approvedMedications}
          />
        </div>
        <p className="text-gray-600">{disease.description}</p>
      </div>

      <div className="mb-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-3">Selected Symptoms</h3>
        <div className="flex flex-wrap gap-2">
          {selectedSymptoms.map((symptom, index) => (
            <span
              key={index}
              className="px-3 py-1 bg-indigo-100 text-indigo-800 rounded-full text-sm"
            >
              {symptom}
            </span>
          ))}
        </div>
      </div>

      <MedicationList medications={disease.medications} />

      <div className="mt-4 p-4 bg-yellow-50 rounded-lg">
        <p className="text-yellow-800 text-sm">
          <strong>Note:</strong> This is an AI-generated diagnosis for reference only. 
          Please consult with a healthcare professional for accurate medical advice.
        </p>
      </div>
    </div>
  );
}