import React from 'react';
import { Document, Page, StyleSheet, PDFDownloadLink } from '@react-pdf/renderer';
import { Disease, Hospital, ApprovedMedication } from '../types/medical';
import { format } from 'date-fns';
import { calculateHealthMetrics } from '../utils/healthMetrics';
import PDFHeader from './pdf/PDFHeader';
import PDFDietarySection from './pdf/PDFDietarySection';
import PDFHealthMetrics from './pdf/PDFHealthMetrics';
import PDFMedicationSection from './pdf/PDFMedicationSection';
import PDFDoctorApprovalSection from './pdf/PDFDoctorApprovalSection';

const styles = StyleSheet.create({
  page: {
    padding: 20,
    fontSize: 12,
  },
  footer: {
    position: 'absolute',
    bottom: 30,
    left: 30,
    right: 30,
    textAlign: 'center',
    color: '#6b7280',
    fontSize: 8,
    borderTop: 1,
    borderTopColor: '#e5e7eb',
    paddingTop: 10,
  },
});

interface MedicalReportProps {
  disease: Disease;
  selectedSymptoms: string[];
  hospitals: Hospital[];
  approvedMedications: ApprovedMedication[];
}

const MedicalReport = ({ disease, selectedSymptoms, hospitals, approvedMedications }: MedicalReportProps) => {
  const healthMetrics = calculateHealthMetrics(selectedSymptoms);

  return (
    <Document>
      <Page size="A4" style={styles.page}>
        <PDFHeader />
        <PDFHealthMetrics 
          healthMetrics={healthMetrics}
          selectedSymptoms={selectedSymptoms}
        />
        <PDFMedicationSection medications={approvedMedications} />
        <PDFDoctorApprovalSection medications={approvedMedications} />
        <PDFDietarySection condition={disease.name} />
      </Page>
    </Document>
  );
};

interface PDFDownloadButtonProps {
  disease: Disease;
  selectedSymptoms: string[];
  hospitals: Hospital[];
  approvedMedications: ApprovedMedication[];
}

export default function PDFDownloadButton({ 
  disease, 
  selectedSymptoms, 
  hospitals,
  approvedMedications 
}: PDFDownloadButtonProps) {
  return (
    <PDFDownloadLink
      document={
        <MedicalReport 
          disease={disease} 
          selectedSymptoms={selectedSymptoms} 
          hospitals={hospitals}
          approvedMedications={approvedMedications}
        />
      }
      fileName={`medical-report-${format(new Date(), 'yyyy-MM-dd')}.pdf`}
      className="inline-flex items-center px-4 py-2 bg-indigo-500 text-white rounded-lg hover:bg-indigo-600 transition-colors"
    >
      {({ loading }) =>
        loading ? 'Generating PDF...' : 'Download Medical Report'
      }
    </PDFDownloadLink>
  );
}