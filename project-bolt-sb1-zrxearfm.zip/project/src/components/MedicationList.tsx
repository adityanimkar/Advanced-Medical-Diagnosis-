import React from 'react';
import { Pill, Clock, Calendar } from 'lucide-react';
import { Medication } from '../types/medical';

interface MedicationListProps {
  medications: Medication[];
}

export function MedicationList({ medications }: MedicationListProps) {
  return (
    <div className="mb-6">
      <h3 className="text-lg font-semibold text-gray-800 mb-3">Recommended Medications</h3>
      <div className="space-y-4">
        {medications.map((medication, index) => (
          <div key={index} className="bg-indigo-50 p-4 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <Pill className="text-indigo-500" size={20} />
              <span className="font-medium text-indigo-800">{medication.name}</span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
              <div className="flex items-center gap-2">
                <span className="text-gray-600">Dosage:</span>
                <span className="font-medium">{medication.dosage}</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock size={16} className="text-gray-500" />
                <span className="text-gray-600">Frequency:</span>
                <span className="font-medium">{medication.frequency}</span>
              </div>
              <div className="flex items-center gap-2">
                <Calendar size={16} className="text-gray-500" />
                <span className="text-gray-600">Duration:</span>
                <span className="font-medium">{medication.duration}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}