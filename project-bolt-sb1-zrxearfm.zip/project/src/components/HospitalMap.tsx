import React, { useEffect, useState } from 'react';
import { MapPin, Navigation, AlertCircle } from 'lucide-react';
import { Hospital } from '../types/medical';

interface Location {
  latitude: number;
  longitude: number;
}

interface HospitalMapProps {
  hospitals: Hospital[];
}

export default function HospitalMap({ hospitals }: HospitalMapProps) {
  const [userLocation, setUserLocation] = useState<Location | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setUserLocation({
            latitude: position.coords.latitude,
            longitude: position.coords.longitude
          });
          setLoading(false);
          setError(null);
        },
        (error) => {
          setLoading(false);
          switch (error.code) {
            case error.PERMISSION_DENIED:
              setError("Please enable location services to see nearby hospitals");
              break;
            case error.POSITION_UNAVAILABLE:
              setError("Location information is unavailable");
              break;
            case error.TIMEOUT:
              setError("Location request timed out");
              break;
            default:
              setError("An unknown error occurred");
          }
        },
        {
          enableHighAccuracy: true,
          timeout: 5000,
          maximumAge: 0
        }
      );
    } else {
      setLoading(false);
      setError("Geolocation is not supported by your browser");
    }
  }, []);

  const getGoogleMapsUrl = (hospital: Hospital) => {
    if (!userLocation) return '#';
    return `https://www.google.com/maps/dir/?api=1&origin=${userLocation.latitude},${userLocation.longitude}&destination=${encodeURIComponent(hospital.address)}`;
  };

  if (loading) {
    return (
      <div className="bg-white p-6 rounded-lg shadow-lg text-center">
        <p className="text-gray-600">Loading location data...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-white p-6 rounded-lg shadow-lg">
        <div className="flex items-center gap-2 text-yellow-600 mb-4">
          <AlertCircle className="w-5 h-5" />
          <p className="text-sm">{error}</p>
        </div>
        <div className="space-y-4">
          {hospitals.map((hospital) => (
            <div key={hospital.id} className="border rounded-lg p-4">
              <h4 className="font-semibold text-gray-800 mb-2">{hospital.name}</h4>
              <p className="text-sm text-gray-600 mb-2">{hospital.address}</p>
              <div className="flex flex-wrap gap-2">
                {hospital.specialties.map((specialty, index) => (
                  <span
                    key={index}
                    className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full"
                  >
                    {specialty}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white p-6 rounded-lg shadow-lg">
      <div className="flex items-center gap-2 mb-6">
        <MapPin className="text-blue-500" />
        <h3 className="text-xl font-semibold text-gray-800">Nearby Hospitals</h3>
      </div>

      <div className="space-y-4">
        {hospitals.map((hospital) => (
          <div key={hospital.id} className="border rounded-lg p-4 hover:shadow-md transition-all">
            <div className="flex justify-between items-start">
              <div>
                <h4 className="font-semibold text-gray-800 mb-2">{hospital.name}</h4>
                <p className="text-sm text-gray-600 mb-2">{hospital.address}</p>
                <div className="flex flex-wrap gap-2">
                  {hospital.specialties.map((specialty, index) => (
                    <span
                      key={index}
                      className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full"
                    >
                      {specialty}
                    </span>
                  ))}
                </div>
              </div>
              <a
                href={getGoogleMapsUrl(hospital)}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
              >
                <Navigation size={16} />
                Directions
              </a>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}