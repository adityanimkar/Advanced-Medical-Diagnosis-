import React from 'react';
import { Symptom } from '../types/medical';
import { AlertCircle } from 'lucide-react';

interface SymptomSelectorProps {
  symptoms: Symptom[];
  selectedSymptoms: string[];
  onSymptomSelect: (symptom: string) => void;
}

export default function SymptomSelector({ symptoms, selectedSymptoms, onSymptomSelect }: SymptomSelectorProps) {
  const categories = [...new Set(symptoms.map(s => s.category))];

  return (
    <div className="bg-white p-6 rounded-lg shadow-lg">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <AlertCircle className="text-blue-500" />
          <h2 className="text-xl font-semibold">Select Symptoms (Choose up to 5)</h2>
        </div>
        <span className="text-sm text-gray-600">
          Selected: {selectedSymptoms.length}/5
        </span>
      </div>
      
      {categories.map(category => (
        <div key={category} className="mb-4">
          <h3 className="text-lg font-medium text-gray-700 mb-2">{category}</h3>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
            {symptoms
              .filter(s => s.category === category)
              .map(symptom => (
                <button
                  key={symptom.id}
                  onClick={() => onSymptomSelect(symptom.name)}
                  className={`p-2 rounded-md text-sm transition-colors ${
                    selectedSymptoms.includes(symptom.name)
                      ? 'bg-blue-500 text-white'
                      : 'bg-gray-100 hover:bg-gray-200 text-gray-700'
                  } ${selectedSymptoms.length >= 5 && !selectedSymptoms.includes(symptom.name)
                      ? 'opacity-50 cursor-not-allowed'
                      : ''
                  }`}
                  disabled={selectedSymptoms.length >= 5 && !selectedSymptoms.includes(symptom.name)}
                >
                  {symptom.name}
                </button>
              ))}
          </div>
        </div>
      ))}
    </div>
  );
}