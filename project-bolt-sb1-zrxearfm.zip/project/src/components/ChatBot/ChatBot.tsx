import React, { useState, useRef, useEffect } from 'react';
import { MessageCircle, Send } from 'lucide-react';
import { Message } from '../../types/voice';
import { generateResponse } from '../../utils/chatbot/responseGenerator';
import { analyzeEmotion } from '../../utils/emotionAnalysis';
import ChatMessage from './ChatMessage';
import ChatInput from './ChatInput';

export default function ChatBot() {
  const [messages, setMessages] = useState<Message[]>([
    {
      text: "Hello! I'm your medical assistant. How can I help you today?",
      isBot: true,
      emotion: 'neutral',
      timestamp: new Date(),
    },
  ]);
  const [isOpen, setIsOpen] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async (input: string) => {
    const emotion = analyzeEmotion(input);
    const userMessage: Message = {
      text: input,
      isBot: false,
      emotion,
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);

    // Generate response using the enhanced medical dataset
    const response = generateResponse(input, emotion);
    const botMessage: Message = {
      text: response,
      isBot: true,
      emotion: 'neutral',
      timestamp: new Date(),
    };

    setTimeout(() => {
      setMessages(prev => [...prev, botMessage]);
    }, 500);
  };

  return (
    <div className="fixed bottom-4 right-4 z-50">
      {isOpen && (
        <div className="bg-white rounded-lg shadow-xl w-80 h-96 flex flex-col">
          <div className="bg-blue-500 text-white p-4 rounded-t-lg flex items-center">
            <MessageCircle className="mr-2" size={20} />
            <h3 className="font-semibold">Medical Assistant</h3>
          </div>
          
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {messages.map((message, index) => (
              <ChatMessage key={index} message={message} />
            ))}
            <div ref={messagesEndRef} />
          </div>

          <div className="p-4 border-t">
            <ChatInput onSend={handleSend} />
          </div>
        </div>
      )}

      <button
        onClick={() => setIsOpen(!isOpen)}
        className="bg-blue-500 text-white p-4 rounded-full shadow-lg hover:bg-blue-600 transition-colors"
      >
        <MessageCircle size={24} />
      </button>
    </div>
  );
}