import React from 'react';
import { Disease } from '../types/medical';
import { calculateHealthMetrics } from '../utils/healthMetrics';
import { AlertTriangle, CheckCircle, AlertCircle, Activity, TrendingUp } from 'lucide-react';
import RiskAnalysis from './RiskAnalysis';

interface HealthGraphProps {
  disease: Disease;
  selectedSymptoms: string[];
}

export default function HealthGraph({ disease, selectedSymptoms }: HealthGraphProps) {
  const healthMetrics = calculateHealthMetrics(selectedSymptoms);

  const getRiskIcon = () => {
    switch (healthMetrics.level) {
      case 'Low': return <CheckCircle className="text-green-500" size={24} />;
      case 'Medium': return <AlertCircle className="text-yellow-500" size={24} />;
      case 'High': return <AlertTriangle className="text-red-500" size={24} />;
    }
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-lg mb-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <Activity className="text-blue-500" size={24} />
          <h3 className="text-lg font-semibold text-gray-800">Health Risk Assessment</h3>
        </div>
        <div className="flex items-center gap-2">
          <TrendingUp className="text-blue-500" size={20} />
          <span className="text-sm font-medium text-gray-600">Overall Analysis</span>
        </div>
      </div>

      {/* Risk Score Circle */}
      <div className="flex justify-center mb-8">
        <div className="relative w-48 h-48">
          <svg className="w-full h-full -rotate-90">
            <circle
              cx="96"
              cy="96"
              r="88"
              fill="none"
              stroke="#eee"
              strokeWidth="12"
            />
            <circle
              cx="96"
              cy="96"
              r="88"
              fill="none"
              stroke={`var(--${healthMetrics.color}-500)`}
              strokeWidth="12"
              strokeDasharray={`${healthMetrics.score * 5.53} 553`}
              strokeLinecap="round"
              className="transition-all duration-1000"
            />
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            {getRiskIcon()}
            <span className="text-3xl font-bold mt-2">{Math.round(healthMetrics.score)}%</span>
            <span className={`text-sm font-medium text-${healthMetrics.color}-500`}>
              {healthMetrics.level} Risk Level
            </span>
          </div>
        </div>
      </div>

      {/* Risk Categories */}
      <div className="grid grid-cols-3 gap-4 mb-8">
        {['High', 'Medium', 'Low'].map((level) => (
          <div key={level} 
               className={`text-center p-4 rounded-lg ${
                 healthMetrics.level === level ? 'bg-blue-50 ring-2 ring-blue-500' : 'bg-gray-50'
               }`}>
            <div className="h-24 relative overflow-hidden rounded-lg">
              <div
                className={`absolute bottom-0 w-full transition-all duration-500 ${
                  healthMetrics.level === level
                    ? 'bg-blue-500 opacity-100'
                    : 'bg-gray-300 opacity-40'
                }`}
                style={{
                  height: healthMetrics.level === level ? '100%' : '30%',
                }}
              />
            </div>
            <span className={`text-sm font-medium mt-2 block ${
              healthMetrics.level === level ? 'text-blue-700' : 'text-gray-600'
            }`}>{level}</span>
          </div>
        ))}
      </div>

      {/* Symptom Analysis */}
      <div className="space-y-4">
        <h4 className="text-sm font-semibold text-gray-700 mb-3">Detailed Symptom Analysis</h4>
        {selectedSymptoms.map((symptom, index) => (
          <RiskAnalysis
            key={index}
            symptom={symptom}
            riskLevel={healthMetrics.level}
            score={Math.round(healthMetrics.score)}
          />
        ))}
      </div>
    </div>
  );
}