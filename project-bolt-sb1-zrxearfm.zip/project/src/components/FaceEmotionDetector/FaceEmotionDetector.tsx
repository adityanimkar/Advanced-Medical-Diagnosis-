import React, { useRef, useEffect, useState } from 'react';
import Webcam from 'react-webcam';
import * as faceapi from 'face-api.js';
import { Camera, Loader2, AlertCircle } from 'lucide-react';
import { EmotionData } from '../../types/medical';
import EmotionReport from './EmotionReport';
import { loadFaceDetectionModels } from '../../utils/faceDetection';

export default function FaceEmotionDetector() {
  const webcamRef = useRef<Webcam>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isModelLoading, setIsModelLoading] = useState(true);
  const [loadError, setLoadError] = useState(false);
  const [emotionData, setEmotionData] = useState<EmotionData | null>(null);

  useEffect(() => {
    const initializeModels = async () => {
      const success = await loadFaceDetectionModels();
      setIsModelLoading(false);
      setLoadError(!success);
    };

    initializeModels();
  }, []);

  const handleStream = async () => {
    if (webcamRef.current?.video && canvasRef.current) {
      const video = webcamRef.current.video;
      const canvas = canvasRef.current;

      try {
        const detections = await faceapi
          .detectSingleFace(video, new faceapi.TinyFaceDetectorOptions())
          .withFaceExpressions();

        if (detections) {
          const dims = faceapi.matchDimensions(canvas, video, true);
          const resizedDetections = faceapi.resizeResults(detections, dims);
          
          const ctx = canvas.getContext('2d');
          ctx?.clearRect(0, 0, canvas.width, canvas.height);
          faceapi.draw.drawDetections(canvas, resizedDetections);

          const emotions = detections.expressions;
          const dominantEmotion = Object.entries(emotions).reduce((a, b) => 
            a[1] > b[1] ? a : b
          )[0];

          setEmotionData({
            timestamp: new Date(),
            emotions: emotions,
            dominant: dominantEmotion
          });
        }
      } catch (error) {
        console.error('Error processing video frame:', error);
      }
    }
  };

  useEffect(() => {
    if (!isModelLoading && !loadError) {
      const interval = setInterval(handleStream, 100);
      return () => clearInterval(interval);
    }
  }, [isModelLoading, loadError]);

  if (isModelLoading) {
    return (
      <div className="flex items-center justify-center p-8 bg-white rounded-lg shadow-lg">
        <Loader2 className="w-8 h-8 animate-spin text-blue-500 mr-2" />
        <span className="text-gray-600">Loading emotion detection models...</span>
      </div>
    );
  }

  if (loadError) {
    return (
      <div className="flex items-center justify-center p-8 bg-white rounded-lg shadow-lg text-red-500">
        <AlertCircle className="w-6 h-6 mr-2" />
        <span>Failed to load emotion detection models. Please try refreshing the page.</span>
      </div>
    );
  }

  return (
    <div className="bg-white p-6 rounded-lg shadow-lg space-y-6">
      <div className="flex items-center gap-2 mb-4">
        <Camera className="text-blue-500" />
        <h2 className="text-xl font-semibold">Facial Emotion Analysis</h2>
      </div>

      <div className="relative">
        <Webcam
          ref={webcamRef}
          className="rounded-lg w-full"
          mirrored
          screenshotFormat="image/jpeg"
        />
        <canvas
          ref={canvasRef}
          className="absolute top-0 left-0 w-full h-full"
        />
      </div>

      {emotionData && <EmotionReport emotionData={emotionData} />}
    </div>
  );
}