import React from 'react';
import { EmotionData } from '../../types/medical';
import { Smile, Frown, Meh, BarChart2 } from 'lucide-react';
import { format } from 'date-fns';

interface EmotionReportProps {
  emotionData: EmotionData;
}

const emotionIcons = {
  happy: Smile,
  sad: Frown,
  neutral: Meh,
  angry: Frown,
  fearful: Frown,
  disgusted: Frown,
  surprised: Meh,
};

export default function EmotionReport({ emotionData }: EmotionReportProps) {
  const { emotions, dominant, timestamp } = emotionData;

  const getEmotionColor = (emotion: string) => {
    switch (emotion) {
      case 'happy':
        return 'text-green-500';
      case 'sad':
      case 'angry':
      case 'fearful':
      case 'disgusted':
        return 'text-red-500';
      default:
        return 'text-yellow-500';
    }
  };

  const EmotionIcon = emotionIcons[dominant as keyof typeof emotionIcons] || Meh;

  return (
    <div className="mt-6 space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <EmotionIcon className={getEmotionColor(dominant)} size={24} />
          <span className="text-lg font-medium capitalize">{dominant} Expression</span>
        </div>
        <span className="text-sm text-gray-500">
          {format(timestamp, 'HH:mm:ss')}
        </span>
      </div>

      <div className="space-y-3">
        <div className="flex items-center gap-2">
          <BarChart2 className="text-blue-500" size={20} />
          <span className="text-sm font-medium">Emotion Distribution</span>
        </div>
        
        {Object.entries(emotions).map(([emotion, confidence]) => (
          <div key={emotion} className="space-y-1">
            <div className="flex justify-between text-sm">
              <span className="capitalize">{emotion}</span>
              <span>{Math.round(confidence * 100)}%</span>
            </div>
            <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
              <div
                className={`h-full rounded-full ${
                  emotion === dominant ? 'bg-blue-500' : 'bg-gray-400'
                }`}
                style={{ width: `${confidence * 100}%` }}
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}