import React, { useState } from 'react';
import { CheckCircle, XCircle, AlertTriangle } from 'lucide-react';
import { Medication } from '../types/medical';

interface MedicationApprovalProps {
  medications: Medication[];
}

interface ApprovedMedication extends Medication {
  isApproved: boolean;
  approvedBy?: string;
  approvalDate?: Date;
}

export default function MedicationApproval({ medications }: MedicationApprovalProps) {
  const [approvedMedications, setApprovedMedications] = useState<ApprovedMedication[]>(
    medications.map(med => ({ ...med, isApproved: false }))
  );

  const handleApproval = (index: number) => {
    setApprovedMedications(prev => prev.map((med, i) => {
      if (i === index) {
        return {
          ...med,
          isApproved: true,
          approvedBy: "Dr. Sarah Johnson",
          approvalDate: new Date()
        };
      }
      return med;
    }));
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-lg">
      <div className="flex items-center gap-2 mb-6">
        <AlertTriangle className="text-yellow-500" />
        <h3 className="text-xl font-semibold text-gray-800">Medication Approval Status</h3>
      </div>

      <div className="space-y-4">
        {approvedMedications.map((medication, index) => (
          <div key={index} className="border rounded-lg p-4">
            <div className="flex justify-between items-start mb-3">
              <div>
                <h4 className="font-semibold text-gray-800">{medication.name}</h4>
                <p className="text-sm text-gray-600">
                  {medication.dosage} - {medication.frequency}
                </p>
              </div>
              {medication.isApproved ? (
                <div className="flex items-center gap-2 text-green-600">
                  <CheckCircle size={20} />
                  <span className="text-sm font-medium">Approved</span>
                </div>
              ) : (
                <div className="flex items-center gap-2 text-yellow-600">
                  <XCircle size={20} />
                  <span className="text-sm font-medium">Pending Approval</span>
                </div>
              )}
            </div>

            {medication.isApproved ? (
              <div className="bg-green-50 p-3 rounded-lg">
                <p className="text-sm text-green-800">
                  Approved by: {medication.approvedBy}
                </p>
                <p className="text-sm text-green-800">
                  Date: {medication.approvalDate?.toLocaleDateString()}
                </p>
              </div>
            ) : (
              <button
                onClick={() => handleApproval(index)}
                className="w-full mt-2 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
              >
                Request Doctor Approval
              </button>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}