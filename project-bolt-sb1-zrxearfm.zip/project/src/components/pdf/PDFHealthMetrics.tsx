import React from 'react';
import { Text, View, StyleSheet } from '@react-pdf/renderer';
import { HealthMetric } from '../../utils/healthMetrics';

const styles = StyleSheet.create({
  section: {
    margin: 10,
    padding: 10,
    borderBottom: 1,
    borderBottomColor: '#e5e7eb',
  },
  title: {
    fontSize: 16,
    color: '#1e40af',
    marginBottom: 10,
  },
  metric: {
    marginBottom: 8,
  },
  riskLevel: {
    fontSize: 12,
    marginBottom: 4,
    fontWeight: 'bold',
  },
  detail: {
    fontSize: 10,
    color: '#4b5563',
    marginLeft: 15,
  },
});

interface PDFHealthMetricsProps {
  healthMetrics: HealthMetric;
  selectedSymptoms: string[];
}

export default function PDFHealthMetrics({ healthMetrics, selectedSymptoms }: PDFHealthMetricsProps) {
  return (
    <View style={styles.section}>
      <Text style={styles.title}>Health Risk Assessment</Text>
      
      <View style={styles.metric}>
        <Text style={styles.riskLevel}>
          Overall Risk Level: {healthMetrics.level} ({Math.round(healthMetrics.score)}%)
        </Text>
      </View>

      <View style={styles.metric}>
        <Text style={styles.riskLevel}>Reported Symptoms:</Text>
        {selectedSymptoms.map((symptom, index) => (
          <Text key={index} style={styles.detail}>• {symptom}</Text>
        ))}
      </View>
    </View>
  );
}