import React from 'react';
import { Text, View, StyleSheet } from '@react-pdf/renderer';
import { ApprovedMedication } from '../../types/medical';

const styles = StyleSheet.create({
  section: {
    margin: 10,
    padding: 10,
    borderBottom: 1,
    borderBottomColor: '#e5e7eb',
  },
  title: {
    fontSize: 16,
    color: '#1e40af',
    marginBottom: 10,
  },
  approvalBlock: {
    marginBottom: 8,
    padding: 8,
    backgroundColor: '#f0fdf4',
  },
  doctorName: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#047857',
  },
  approvalDetails: {
    fontSize: 10,
    color: '#065f46',
    marginTop: 4,
  },
  disclaimer: {
    fontSize: 9,
    color: '#991b1b',
    marginTop: 8,
    fontStyle: 'italic',
  },
});

interface PDFDoctorApprovalSectionProps {
  medications: ApprovedMedication[];
}

export default function PDFDoctorApprovalSection({ medications }: PDFDoctorApprovalSectionProps) {
  const approvedMeds = medications.filter(med => med.isApproved);

  return (
    <View style={styles.section}>
      <Text style={styles.title}>Doctor's Approval</Text>
      
      {approvedMeds.map((medication, index) => (
        <View key={index} style={styles.approvalBlock}>
          <Text style={styles.doctorName}>
            Approved by: {medication.approvedBy}
          </Text>
          <Text style={styles.approvalDetails}>
            Medication: {medication.name}{'\n'}
            Approval Date: {medication.approvalDate?.toLocaleDateString()}{'\n'}
            Prescription Valid Until: {
              medication.approvalDate ? 
              new Date(medication.approvalDate.getTime() + 30*24*60*60*1000).toLocaleDateString() 
              : 'N/A'
            }
          </Text>
        </View>
      ))}

      <Text style={styles.disclaimer}>
        This prescription is only valid with the doctor's approval stamp and signature.
        Please verify with your healthcare provider before starting any medication.
      </Text>
    </View>
  );
}