import React from 'react';
import { Text, View, StyleSheet } from '@react-pdf/renderer';
import { format } from 'date-fns';

const styles = StyleSheet.create({
  header: {
    padding: 20,
    backgroundColor: '#f3f4f6',
    marginBottom: 20,
  },
  title: {
    fontSize: 24,
    color: '#1e40af',
    marginBottom: 10,
    textAlign: 'center',
  },
  info: {
    fontSize: 10,
    color: '#4b5563',
    marginBottom: 5,
  },
  disclaimer: {
    fontSize: 8,
    color: '#991b1b',
    marginTop: 10,
    textAlign: 'center',
    fontStyle: 'italic',
  },
});

export default function PDFHeader() {
  return (
    <View style={styles.header}>
      <Text style={styles.title}>Medical Diagnosis Report</Text>
      <Text style={styles.info}>Generated on: {format(new Date(), 'PPP')}</Text>
      <Text style={styles.info}>Report ID: {Math.random().toString(36).substr(2, 9).toUpperCase()}</Text>
      <Text style={styles.disclaimer}>
        This is an AI-generated report for reference only. Please consult with healthcare professionals for accurate medical advice.
      </Text>
    </View>
  );
}