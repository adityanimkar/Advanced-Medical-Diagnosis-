import React from 'react';
import { Text, View, StyleSheet } from '@react-pdf/renderer';

const styles = StyleSheet.create({
  section: {
    margin: 10,
    padding: 10,
    borderBottom: 1,
    borderBottomColor: '#e5e7eb',
  },
  title: {
    fontSize: 16,
    color: '#1e40af',
    marginBottom: 10,
  },
  category: {
    fontSize: 12,
    color: '#1f2937',
    marginTop: 8,
    marginBottom: 4,
    fontWeight: 'bold',
  },
  item: {
    fontSize: 10,
    color: '#4b5563',
    marginLeft: 15,
    marginBottom: 3,
  },
  note: {
    fontSize: 9,
    color: '#6b7280',
    marginTop: 8,
    fontStyle: 'italic',
  },
});

interface PDFDietarySectionProps {
  condition: string;
}

export default function PDFDietarySection({ condition }: PDFDietarySectionProps) {
  const getDietaryRecommendations = () => ({
    recommended: [
      'Fresh fruits and vegetables rich in antioxidants',
      'Lean proteins (fish, chicken, legumes)',
      'Whole grains and complex carbohydrates',
      'Healthy fats (olive oil, avocados, nuts)',
      'Probiotic-rich foods',
    ],
    avoid: [
      'Processed and packaged foods',
      'Excessive sugar and artificial sweeteners',
      'Saturated and trans fats',
      'High-sodium foods',
      'Caffeine and alcoholic beverages',
    ],
    supplements: [
      'Vitamin D3',
      'Omega-3 fatty acids',
      'Probiotics',
      'Multivitamins',
    ],
  });

  const dietary = getDietaryRecommendations();

  return (
    <View style={styles.section}>
      <Text style={styles.title}>Dietary Recommendations</Text>
      
      <Text style={styles.category}>Recommended Foods:</Text>
      {dietary.recommended.map((item, index) => (
        <Text key={index} style={styles.item}>• {item}</Text>
      ))}

      <Text style={styles.category}>Foods to Avoid:</Text>
      {dietary.avoid.map((item, index) => (
        <Text key={index} style={styles.item}>• {item}</Text>
      ))}

      <Text style={styles.category}>Recommended Supplements:</Text>
      {dietary.supplements.map((item, index) => (
        <Text key={index} style={styles.item}>• {item}</Text>
      ))}

      <Text style={styles.note}>
        Note: These dietary recommendations are general guidelines. Please consult with a 
        registered dietitian for personalized advice based on your specific condition.
      </Text>
    </View>
  );
}