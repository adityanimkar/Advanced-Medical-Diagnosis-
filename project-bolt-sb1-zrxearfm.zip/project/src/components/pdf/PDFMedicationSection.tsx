import React from 'react';
import { Text, View, StyleSheet } from '@react-pdf/renderer';
import { ApprovedMedication } from '../../types/medical';

const styles = StyleSheet.create({
  section: {
    margin: 10,
    padding: 10,
    borderBottom: 1,
    borderBottomColor: '#e5e7eb',
  },
  title: {
    fontSize: 16,
    color: '#1e40af',
    marginBottom: 10,
  },
  medication: {
    marginBottom: 8,
  },
  medicationName: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#1f2937',
  },
  details: {
    fontSize: 10,
    color: '#4b5563',
    marginLeft: 15,
  },
  approval: {
    fontSize: 10,
    color: '#047857',
    marginTop: 4,
    marginLeft: 15,
  },
  warning: {
    fontSize: 9,
    color: '#991b1b',
    marginTop: 8,
    fontStyle: 'italic',
  },
  noMedications: {
    fontSize: 10,
    color: '#4b5563',
    fontStyle: 'italic',
  },
});

interface PDFMedicationSectionProps {
  medications: ApprovedMedication[];
}

export default function PDFMedicationSection({ medications = [] }: PDFMedicationSectionProps) {
  return (
    <View style={styles.section}>
      <Text style={styles.title}>Prescribed Medications</Text>
      
      {medications.length === 0 ? (
        <Text style={styles.noMedications}>No medications have been prescribed yet.</Text>
      ) : (
        medications.map((medication, index) => (
          <View key={index} style={styles.medication}>
            <Text style={styles.medicationName}>{medication.name}</Text>
            <Text style={styles.details}>Dosage: {medication.dosage}</Text>
            <Text style={styles.details}>Frequency: {medication.frequency}</Text>
            <Text style={styles.details}>Duration: {medication.duration}</Text>
            {medication.isApproved && medication.approvedBy && medication.approvalDate && (
              <Text style={styles.approval}>
                ✓ Approved by {medication.approvedBy} on {medication.approvalDate.toLocaleDateString()}
              </Text>
            )}
          </View>
        ))
      )}

      <Text style={styles.warning}>
        * Only approved medications are listed in this report. Please consult with your doctor before starting any medication.
      </Text>
    </View>
  );
}