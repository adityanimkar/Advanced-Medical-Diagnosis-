import React, { useState } from 'react';
import StartPage from './pages/StartPage';
import DiagnosisPage from './pages/DiagnosisPage';

function App() {
  const [started, setStarted] = useState(false);

  return (
    <>
      {!started ? (
        <StartPage onStart={() => setStarted(true)} />
      ) : (
        <DiagnosisPage />
      )}
    </>
  );
}

export default App;